#!/bin/sh
cd "$(cd "$(dirname "$0")" && pwd)"
mkdir ./output
chmod +x ./exec/xdelta3_x64_linux
echo Place the files to be patched in the \"original\" directory with the following names:
echo --------------------
echo "Version 1.0 - Tomodachi Collection (Japan) [b].nds"
echo --------------------
echo Patched files will be in the \"output\" directory
read -p "Press enter to continue..." inp
./exec/xdelta3_x64_linux -v -d -s "./original/Version 1.0 - Tomodachi Collection (Japan) [b].nds" "vcdiff/Version 1.0 - Tomodachi Collection (Japan) [b].nds.vcdiff" "./output/tomodachi collection ESP 1.0.nds"
