@echo off
CHCP 65001
mkdir output
echo Place the files to be patched in the "original" directory with the following names:
echo --------------------
echo Version 1.0 - Tomodachi Collection (Japan) [b].nds
echo --------------------
echo Patched files will be in the "output" directory
pause
exec\xdelta3_x86_64_win.exe -v -d -s ".\original\Version 1.0 - Tomodachi Collection (Japan) [b].nds" ".\vcdiff\Version 1.0 - Tomodachi Collection (Japan) [b].nds.vcdiff" ".\output\tomodachi collection ESP 1.0.nds"
echo Completed!
@pause
