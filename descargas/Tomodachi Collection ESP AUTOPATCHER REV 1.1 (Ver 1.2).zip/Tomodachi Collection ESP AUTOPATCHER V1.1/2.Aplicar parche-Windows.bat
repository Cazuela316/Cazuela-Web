@echo off
CHCP 65001
mkdir output
echo Place the files to be patched in the "original" directory with the following names:
echo --------------------
echo Tomodachi Collection (Japan) (Rev 1).nds
echo --------------------
echo Patched files will be in the "output" directory
pause
exec\xdelta3_x86_64_win.exe -v -d -s ".\original\Tomodachi Collection (Japan) (Rev 1).nds" ".\vcdiff\Tomodachi Collection (Japan) (Rev 1).nds.vcdiff" ".\output\Tomodachi collection ESP REV1.1.nds"
echo Completed!
@pause
