#!/bin/sh
cd "$(cd "$(dirname "$0")" && pwd)"
mkdir ./output
chmod +x ./exec/xdelta3_x64_linux
echo Place the files to be patched in the \"original\" directory with the following names:
echo --------------------
echo "Tomodachi Collection (Japan) (Rev 1).nds"
echo --------------------
echo Patched files will be in the \"output\" directory
read -p "Press enter to continue..." inp
./exec/xdelta3_x64_linux -v -d -s "./original/Tomodachi Collection (Japan) (Rev 1).nds" "vcdiff/Tomodachi Collection (Japan) (Rev 1).nds.vcdiff" "./output/Tomodachi collection ESP REV1.1.nds"
